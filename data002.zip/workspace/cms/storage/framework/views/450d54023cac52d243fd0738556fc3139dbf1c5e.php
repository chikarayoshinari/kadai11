<!-- resources/views/books.blade.php -->



<?php $__env->startSection('content'); ?>
    
    
    <div class="panel-body">
        <!-- バリデーションエラーの表示に使用-->
        <?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- バリデーションエラーの表示に使用-->
        
        <!-- 本登録フォーム -->
        <form action="<?php echo e(url('books')); ?>" method="POST" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            
            <!-- 本のタイトル -->
            <div class="form-group">
                <div	class="col-sm-6">	
								<label	for="book"	class="col-sm-3	control-label">Book</label>	
								<input	type="text"	name="item_name"	id="book-name"	class="form-control">	
				</div>
								<div	class="col-sm-6">	
								<label	for="amount"	class="col-sm-3	control-label">金額</label>	
								<input	type="text"	name="item_amount"	id="book-amount"	class="form-control">	
				</div>	
					
				<div	class="col-sm-6">	
								<label	for="number"	class="col-sm-3	control-label">数</label>	
								<input	type="text"	name="item_number"	id="book-number"	class="form-control">	
				</div>	
					
						<div	class="col-sm-6">	
								<label	for="published"	class="col-sm-3	control-label">公開日</label>	
								<input	type="date"	name="published"	id="book-published"	class="form-control">	
				</div>	
                
                

                

            </div>
            
            <!-- 本 登録ボタン -->
            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-6">
                    <button type="submit" class="btn btn-default">
                        <i class="glyphicon glyphicon-plus"></i> Save
                    </button>
                </div>
            </div>
        </form>
        
        
         <!-- 現在 本 -->
         <?php if(count($books) > 0): ?>
            <div class="panel panel-default">
                <div class="panel-heading"> 
                    現在 本
                </div>
                <div class="panel-body">
                <table class="table table-striped task-table">
                    <!-- テーブルヘッダ -->
                    <thead>
                        <th>本一覧</th>
                        <th>&nbsp;</th>
                    </thead>
                    <!-- テーブル本体 -->
                    <tbody>
                         <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <!-- 本タイトル -->
                                <td class="table-text">
                                    <div><?php echo e($book->item_name); ?></div>
                                </td>
                                
                                <!--	本:	更新ボタン	-->	<td>					<form	action="<?php echo e(url('booksedit/'.$book->id)); ?>"	method="POST">								
                                <?php echo e(csrf_field()); ?>									<button	type="submit"	class="btn	btn-primary">												
                                <i	class="glyphicon	glyphicon-pencil"></i>	更新							
                                </button>					</form>	</td
                                
                                
                                
                                <!-- 本: 削除ボタン -->
                                <td>
                                <form action="<?php echo e(url('book/delete/'.$book->id)); ?>" method="POST">
                                        
                                        <?php echo e(csrf_field()); ?>


                                        <button type="submit" class="btn btn-danger"> <i class="glyphicon glyphicon-trash"></i> 
                                            削除
                                        </button>
                                    </form>
                                </td>
                                
                            </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
    <!--  ook: 既に登録されてる本 リスト -->
   
    </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>